<!DOCTYPE html>
<html>
	<!-- CSE3026, Fall 2015 - "Quote of the Day" Ajax example -->
	
	<head>
		<title>Quote of the Day</title>
		<meta charset="UTF-8" />
	</head>	
		
	<body>
		<h1>CSE 3026 - Quote of the Day</h1>
		
		<article>
			<section>
				<blockquote>
						<p>Whenever you find that you are on the side of the majority,
it is time to reform.
	-- Mark Twain</p>

				</blockquote>
			</section>
		</article>
	</body>
</html>
			