<!DOCTYPE html>
<html>
	<head>
		<title>Params</title>
		<style type="text/css">
			body {
				font-family: Calibri, Verdana, Helvetica, Tahoma, Arial, sans-serif;
			}
			
			h2, p {				
				display:inline;
			}			
			
			
			pre {
				border: 1px dashed #eeeeff;
				background-color: #fbfbff;
				padding: 0.2em;
				margin-left: 1em;
				margin-right: 1em;
				margin-top: 0.2em;
				margin-bottom: 1em;
			}
		</style>
	</head>
	
		
	<body>
		<h1>Params Debugger</h1>
		
		<ul>
			<li>Request URL: http://selab.hanyang.ac.kr/courses/cse326/2019/lecture/resources/params.php
</li>
			<li>
				<a target="_blank" href="http://en.wikipedia.org/wiki/Hypertext_Transfer_Protocol#Request_methods" alt="Request method on wiki">Request methods</a>:
				 GET

			</li>
		</ul>
				
		<h2>
			<a target="_blank" href="http://php.net/manual/en/reserved.variables.get.php">$_GET</a>
		</h2>
		<p> : HTTP GET query parameters (parameters in the URL such as params.php?<em>name</em>=<em>value</em>&amp;<em>name</em>=<em>value</em>)</p>
		<pre>Array
(
)
</pre>
		
		<h2>
			<a target="_blank" href="http://php.net/manual/en/reserved.variables.files.php">$_FILES</a>
		</h2>
		<p> : uploaded files</p>
		<pre>Array
(
)
</pre>

		<h2>
			<a target="_blank" href="http://php.net/manual/en/reserved.variables.cookie.php">$_COOKIE</a>
		</h2>
		<p> : cookies sent by your browser along with the request</p>
		<pre>Array
(
    [$Version] => 1
    [PHPSESSID] => f98fvelp7jh4fu9da79bbn0lik
    [$Path] => /
)
</pre>
s
		<h2>
			<a target="_blank" href="http://php.net/manual/en/reserved.variables.server.php">$_SERVER</a>
		</h2>
		<p> : web server state and settings</p>
		<pre>Array
(
    [HTTP_HOST] => selab.hanyang.ac.kr
    [HTTP_REFERER] => http://selab.hanyang.ac.kr/courses/cse326/2019/lecture/06-forms.html
    [HTTP_COOKIE] => $Version=1; PHPSESSID=f98fvelp7jh4fu9da79bbn0lik; $Path=/
    [HTTP_USER_AGENT] => Mozilla/4.5 (compatible; HTTrack 3.0x; Windows 98)
    [HTTP_ACCEPT] => text/html,image/png,image/jpeg,image/pjpeg,image/x-xbitmap,image/svg+xml,image/gif;q=0.9,*/*;q=0.1
    [HTTP_ACCEPT_LANGUAGE] => en, *
    [HTTP_ACCEPT_ENCODING] => gzip, identity;q=0.9
    [HTTP_X_FORWARDED_PROTO] => https
    [HTTP_X_FORWARDED_PORT] => 443
    [HTTP_X_APPLE_SERVICE_WEBCALSSL_ENABLED] => true
    [HTTP_X_APPLE_SERVICE_PROFILE_MANAGER_ENABLED] => true
    [HTTP_X_FORWARDED_HOST] => selab.hanyang.ac.kr
    [HTTP_X_FORWARDED_SERVER] => selab.hanyang.ac.kr
    [HTTP_CONNECTION] => Keep-Alive
    [PATH] => /usr/bin:/bin:/usr/sbin:/sbin
    [SERVER_SIGNATURE] => <address>Apache Server at selab.hanyang.ac.kr Port 80</address>

    [SERVER_SOFTWARE] => Apache
    [SERVER_NAME] => selab.hanyang.ac.kr
    [SERVER_ADDR] => 127.0.0.1
    [SERVER_PORT] => 80
    [REMOTE_ADDR] => 211.195.216.156
    [DOCUMENT_ROOT] => /Library/Server/Web/www
    [REQUEST_SCHEME] => http
    [CONTEXT_PREFIX] => 
    [CONTEXT_DOCUMENT_ROOT] => /Library/Server/Web/www
    [SERVER_ADMIN] => admin@example.com
    [SCRIPT_FILENAME] => /Library/Server/Web/www/courses/cse326/2019/lecture/resources/params.php
    [REMOTE_PORT] => 53950
    [GATEWAY_INTERFACE] => CGI/1.1
    [SERVER_PROTOCOL] => HTTP/1.1
    [REQUEST_METHOD] => GET
    [QUERY_STRING] => 
    [REQUEST_URI] => /courses/cse326/2019/lecture/resources/params.php
    [SCRIPT_NAME] => /courses/cse326/2019/lecture/resources/params.php
    [PHP_SELF] => /courses/cse326/2019/lecture/resources/params.php
    [REQUEST_TIME_FLOAT] => 1570630875.221
    [REQUEST_TIME] => 1570630875
)
</pre>
	</body>
</html>
